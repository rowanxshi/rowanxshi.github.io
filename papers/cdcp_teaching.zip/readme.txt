This folder contains everything to compile the teaching slides from teaching.tex.

* teaching_withnotes.pdf is a version of the slides with additional details for the instructor:
* teaching_withoutnotes.pdf is a version of the slides without the additional details (for display)

When compiling the slides from teaching.tex, the details can be omitted (included) by commenting out (uncommenting) the second line of teaching.tex.

The slides are ready to teach as-is, or can serve as a starting point for further edits.
